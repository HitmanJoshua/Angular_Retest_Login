import { Component, OnInit } from '@angular/core';
import { LocalapiService } from 'src/app/services/localapi.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  one;
  user;
  pass;
  flag;
  list;
  user1;
  pass1;
  constructor(private localApiService: LocalapiService) { }

  ngOnInit() {
    this.list=[];
    this.one=[];
    this.flag = null;
    this.localApiService.getusers().subscribe(
      data=>{
        this.list=JSON.parse(JSON.stringify(data));
        console.log(this.list);
      }
    )
  }
  login(){
    this.list.map(
      obj=>{
        if((this.user==obj.name)&&(this.pass==obj.pass)){
          this.flag=1;
        }
      }
    )
    // for(this.one in this.list){
    //   // if((this.user==one.user)&&(this.pass==one.pass)){
    //   //   this.flag=1;
    //   console.log(this.one);
    //   }
    }
  
  // login() {
  //   this.localApiService.getusers().subscribe(
  //     data => {
  //       this.list = JSON.parse(JSON.stringify(data));
  //       if((this.user==this.list.user)&&(this.pass==this.list.pass)){
  //         this.flag=1;
  //       }
  //       console.log(this.list);
  //     }
  //   )
  //   if ((this.user == "amit") && (this.pass == "test123")) {
  //     this.flag = 1;
  //   }
  // }
  addme() {
    this.localApiService.putuser({name:this.user1,pass:this.pass1}).subscribe(
      data => console.log(data)
    );
  }


}
