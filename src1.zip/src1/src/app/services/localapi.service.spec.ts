import { TestBed } from '@angular/core/testing';

import { LocalapiService } from './localapi.service';

describe('LocalapiService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LocalapiService = TestBed.get(LocalapiService);
    expect(service).toBeTruthy();
  });
});
