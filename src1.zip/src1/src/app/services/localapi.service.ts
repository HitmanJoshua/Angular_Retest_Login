import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


const URL="http://localhost:3000/buddy" ;

const httpOptions={
  headers:new HttpHeaders({
    'Content-type':'application/json',
    'Access-Control-Allow-Origin': '*'
  })
};

@Injectable({
  providedIn: 'root'
})
export class LocalapiService {

  constructor(private http:HttpClient) { }
  getusers(){
    return this.http.get(URL,httpOptions);
  }
  putuser(user){
    console.log(user);
    
    return this.http.post("http://localhost:3000/buddy",user);
    console.log("hi");
  }
}
